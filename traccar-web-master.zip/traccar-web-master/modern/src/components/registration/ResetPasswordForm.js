import React from 'react';

const ResetPasswordForm = () => (
  <>
    <div>Reset Password Comming Soon!!!</div>
  </>
);

export default ResetPasswordForm;
