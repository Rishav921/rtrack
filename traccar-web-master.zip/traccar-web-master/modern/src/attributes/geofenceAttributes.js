import t from '../common/localization';

export default {
  speedLimit: {
    name: t('attributeSpeedLimit'),
    type: 'string',
  },
};
